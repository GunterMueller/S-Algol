extern	psint	at_new_line, the_lit, unary_minus ;
extern	char	*symb, the_name[] ;
extern	pntr	lit_type,the_string ;
extern	psreal	real_value ;
