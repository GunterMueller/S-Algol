extern	pntr	mk_vector(),mk_proc(),mk_var(),mk_structure(),mk_field(),
		mk_cons(),mk_struct_table(),mk_const(),mk_string(),
		mk_p_decl(),mk_s_decl(),mk_external(),mk_image(),mk_link(),
		mk_namelist()  ;

