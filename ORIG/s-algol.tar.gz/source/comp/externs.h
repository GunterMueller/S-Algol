FILE *Create_code() ;
FILE *Open_source() ;
FILE *Open_prelude() ;
FILE *Open_std_decls() ;
FILE *Create_flsum() ;
