/**** These are code generation globals ****/

extern	psint	codeword_size ;
extern	unsigned char	*codeword ;
extern	psint	cp,code_base,code_size ;
extern	psint	coding ;
extern	psint	max_seg_size ;
extern	psint	last_segment ;
extern	psint	st_size, st_size2, st_size3, st_size4 ;
extern	psint	ssp, psp, max_ps, max_ms, special ;
extern	psint	mscw_size, lex_level ;
extern	psint	newlin, line_count ;
extern	psint	newlins ;
extern	psint	newlab, block_count, last_block_count ;
